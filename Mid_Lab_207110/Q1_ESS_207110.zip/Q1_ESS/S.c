#include<time.h> 
#include<stdio.h> 
#include<sys/socket.h> 
#include<netinet/in.h> 
#include<string.h> 
#include<sys/select.h> 
#include<pthread.h> 
#include<signal.h> 
#include<stdlib.h> 
#include<fcntl.h>
#include<unistd.h> 
#include<sys/un.h> 
#include<netinet/ip.h> 
#include<arpa/inet.h> 
#include<errno.h>
#include<sys/ipc.h> 
#include<sys/msg.h> 
#include<sys/shm.h>

int main(){
    int usfd; 
	
	struct sockaddr_in userv_addr; 
  	int userv_len,ucli_len; 
  	
  	usfd = socket(AF_INET, SOCK_STREAM, 0); 
  	if(usfd==-1) 
  		perror("\nsocket  "); 
  	
	userv_addr.sin_addr.s_addr = INADDR_ANY;
	userv_addr.sin_family = AF_INET;
	userv_addr.sin_port = htons(8010);
	userv_len = sizeof(userv_addr); 

}
#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x32e21920, "module_layout" },
	{ 0x362f9a8, "__x86_indirect_thunk_r12" },
	{ 0x2b68bd2f, "del_timer" },
	{ 0xdf85ea06, "usb_deregister" },
	{ 0xc6f46339, "init_timer_key" },
	{ 0xf63cc4cc, "usb_register_driver" },
	{ 0x87a21cb3, "__ubsan_handle_out_of_bounds" },
	{ 0x24d273d1, "add_timer" },
	{ 0x15ba50a6, "jiffies" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0xd279582d, "vc_cons" },
	{ 0x4e6e8ea7, "fg_console" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x92997ed8, "_printk" },
	{ 0xbdfb6dbb, "__fentry__" },
};

MODULE_INFO(depends, "");

MODULE_ALIAS("usb:v0C45p1915d*dc*dsc*dp*ic*isc*ip*in*");

MODULE_INFO(srcversion, "FB4609024255EAB3E00C7CF");

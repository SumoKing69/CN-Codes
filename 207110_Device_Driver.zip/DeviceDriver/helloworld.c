#include <linux/init.h> 
#include <linux/kd.h> /* For KDSETLED */ 
#include <linux/module.h> 
#include <linux/tty.h> /* For tty_struct */ 
#include <linux/vt.h> /* For MAX_NR_CONSOLES */ 
#include <linux/vt_kern.h> /* for fg_console */ 
#include <linux/console_struct.h> /* For vc_cons */ 
#include<linux/usb.h>
 
MODULE_DESCRIPTION("Example module illustrating the use of Keyboard LEDs."); 
 
static struct timer_list my_timer; 
static struct tty_driver *my_driver; 
static unsigned long kbledstatus = 0; 
int check = -1;
static struct usb_device *my_usb_device;

#define BLINK_DELAY 15
#define ALL_LEDS_ON 0x07 
#define RESTORE_LEDS 0xFF 
#define BLINK_DURATION 5000

#define VENDOR_ID 0x0c45
#define PRODUCT_ID 0x1915

static struct usb_device_id usb_dev_table [] = {
	{ USB_DEVICE(VENDOR_ID, PRODUCT_ID) },
    {}
};
MODULE_DEVICE_TABLE(usb, usb_dev_table);

static void my_timer_func(struct timer_list *unused) 
{ 
    struct tty_struct *t = vc_cons[fg_console].d->port.tty; 
 
    if (kbledstatus == ALL_LEDS_ON) 
        kbledstatus = RESTORE_LEDS; 
    else 
        kbledstatus = ALL_LEDS_ON; 
 
    (my_driver->ops->ioctl)(t, KDSETLED, kbledstatus); 
 
    my_timer.expires = jiffies + BLINK_DELAY; 
    add_timer(&my_timer); 
} 

static int my_usb_probe(struct usb_interface *intf, const struct usb_device_id *id) {
	printk("my_usb_devdrv - Probe Function\n");
    my_usb_device = interface_to_usbdev(intf);
    printk("The value of check inside check %d",check);
	return 0;
}

static void my_usb_disconnect(struct usb_interface *intf) {
	printk("my_usb_devdrv - Disconnect Function\n");
}

static struct usb_driver my_usb_driver = {
	.name = "my_usb_devdr",
	.id_table = usb_dev_table,
	.probe = my_usb_probe,
	.disconnect = my_usb_disconnect,
};

static int __init start(void) 
{ 
    int result;
    // struct usb_device *dev;
	printk("my_usb_devdrv - Init Function\n");
	result = usb_register(&my_usb_driver);
    printk("The value of check is %d",check);
    if (!my_usb_device) {
        printk("USB device not found\n");
        return -ENODEV;
    }
    check = 0;
    my_driver = vc_cons[fg_console].d->port.tty->driver; 
    pr_info("kbleds: loading\n"); 
    timer_setup(&my_timer, my_timer_func, 0); 
    my_timer.expires = BLINK_DELAY; 
    add_timer(&my_timer);
    return 0;
} 
 
static void __exit cleanup(void) 
{ 
    usb_deregister(&my_usb_driver);
    // if(check == 0){
    pr_info("kbleds: unloading...\n");
    del_timer(&my_timer); 
    (my_driver->ops->ioctl)(vc_cons[fg_console].d->port.tty, KDSETLED, 
                                RESTORE_LEDS);
    // }
} 
 
module_init(start); 
module_exit(cleanup); 
MODULE_LICENSE("GPL");
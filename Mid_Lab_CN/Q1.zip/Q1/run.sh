gcc init.c -o i
./i
gcc ESS.c -o ESS
gcc C1.c -o C1
gcc C2.c -o C2
gcc C3.c -o C3
gcc C4.c -o C4
gcc end.c -o e